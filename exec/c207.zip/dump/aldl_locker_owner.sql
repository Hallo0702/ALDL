-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: j7c207.p.ssafy.io    Database: aldl
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `locker_owner`
--

DROP TABLE IF EXISTS `locker_owner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `locker_owner` (
  `id` bigint NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `locker_hash` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locker_owner`
--

LOCK TABLES `locker_owner` WRITE;
/*!40000 ALTER TABLE `locker_owner` DISABLE KEYS */;
INSERT INTO `locker_owner` VALUES (8,'facquodvisy@naver.com','0x21407a981711d27dfcb58821305cace909916653'),(11,'sal0203@naver.com','0x21407a981711d27dfcb58821305cace909916653'),(19,'dusdml1502@naver.com','0x963d3bf098149c0be68bfa3ce34bb83444c060f6'),(25,'hihihi@naer.com','0x618898b144ec1ed2e487e3b1a57df0e50e37c289'),(27,'kcy63@naver.com','0xd20272e4be24e74e4dd0d230f475f5d78d3e1d00'),(33,'rkd9755@naver.com','0x7a2ee77fb5cc9346231fd06607b4f1e054f893d2'),(37,'vvchldmsdn@naver.com','0xe99cc6414c00523036aff108a1a7dcb0449003ae'),(41,'jihun3104@gmail.com','0x685a48a72d551132cada18814b9e8ed9744b178c'),(43,'jihun3104@gmail.com','0xb2b71d4857d0d6d2832606132c6dd0071ab631da'),(46,'wlsgkq123@gmail.com','0xb2b71d4857d0d6d2832606132c6dd0071ab631da'),(50,'aa@aa.aa','0x5a80bfadb1caa94221731138c97144705cb5017b'),(54,'minji@ssafy.com','0xf32f157ffbaadc26c9b0e380bba1bd7471717f71'),(58,'asd123@naver.com','0x3a94c09fe7340cf5a12216ebc15f2e45699a76e3'),(62,'beckhem96@naver.com','0xe06a144e88b1e87285956c213b8dc5f7bfd2eb70'),(68,'ghdcks@naver.com','0x3cbac3161a9d5560d94cfa95a1d4f7474d01b165'),(70,'user1@example.com','0x7c75625e7c8841e4be20d8abd8d24b2b559fd24d'),(72,'jihun3104@gmail.com','0xe964534f781e3fee04863e1757283d837a68300c'),(76,'user1@example.com','0x12e5826ca8f5470b3152ebf50dfd9d0b6cafe004'),(78,'jihun3104@gmail.com','0x07fc7ab45e6fb3a1c86d0af0566a85f5036297a3'),(80,'leesongjin@naver.com','0x965046574aa68db44114558aa799fee26a0eaaec'),(86,'jihun3104@gmail.com','0x47ceb8f3aa3a455af635a60c2c0392581c68d1e0'),(87,'abovenormal5023@gmail.com','0x5a80bfadb1caa94221731138c97144705cb5017b'),(89,'veta6287@naver.com','0x65a7a70ebd47f03617232a6e583a3a9b946d5aa5'),(95,'test1@naver.com','0x617becc171f1d25db0281a9796f6e6fe63d20db7'),(97,'ohm55545@naver.com','0xf112109c4ef1dc36921b7750ce7af2f1289fcd01'),(103,'dlalswo9801@naver.com','0x0d3d8984bdb1ced82aa8c1edd8f16c8128e2b23e'),(105,'dudtjakdl@naver.com','0x7918de3dba75264f6977ab7dd5d25428e36bb7e0'),(109,'h5282000@naver.com','0xf9706732d69de3ac82d95503af77ca69e284eb73'),(110,'sal0203@naver.com','0xf9706732d69de3ac82d95503af77ca69e284eb73'),(114,'a@a.com','0xe491364171854d70742a0649f6273da741964d4d'),(122,'baekhannah@naver.com','0x164ac493818cf55bdceb06e9e2ffec28d6fb5b17'),(128,'rkd9755@naver.com','0x195784e133078c04bb719495568c534f92f1fef1'),(130,'rkd9755@naver.com','0x212b0c664e9d47bc031f745bf7f55ee2d036040a'),(134,'chosw0812@naver.com','0xc8782a8801738eae7dd966c9397bbac3f54b0353'),(136,'chosw0812@naver.com','0xa4682e7a96a29766b6e4dc559cf230bc280b38a9'),(140,'chob58@naver.com','0xd98595ae5f14d9f2a460451fc2a90f547dbf84ed'),(144,'abovenormal5023@gmail.com','0x0770c6d5bb2c35bc9bbf5881ed3f2a55f6d8f4f1'),(148,'asya390@gmail.com','0xe1d9510696d07c067fc0e2af655370dd1d703036');
/*!40000 ALTER TABLE `locker_owner` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-07 11:09:20
